# Test EuroSoft

### Requirements:
- node.js 7.9.0
- npm 4.3.0
- mongoDB 3.4.*


### How to start a project:
- npm install
- npm run build
- npm start
