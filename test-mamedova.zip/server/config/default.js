module.exports = {
  host: 'localhost',
  port: process.env.PORT || 3000,
  mongo: {
    host: 'mongodb://localhost/delivery'
  }
};
